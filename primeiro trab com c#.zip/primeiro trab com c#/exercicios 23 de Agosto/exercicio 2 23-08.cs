using System;

class Program
{
        static void Main(string[] args)

    {
        Console.WriteLine("descubra o Valor de X");
        double a, b, c, x;
        Console.Write("Digite um numero: ");
        a = double.Parse(Console.ReadLine());
        Console.Write("Digite outro numero: ");
        b = double.Parse(Console.ReadLine());
        Console.Write("Digite mais um número: ");
        c = double.Parse(Console.ReadLine());
        x = a/b+c*5;
        Console.WriteLine("O valor de X é: "+ x);
    }
}