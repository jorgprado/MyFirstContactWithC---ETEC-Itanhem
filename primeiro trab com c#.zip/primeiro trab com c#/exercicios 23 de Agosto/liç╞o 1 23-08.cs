using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Descubra o valor de X");
        double a, b, c, x;
        Console.Write("Digite o primeiro número: ");
        a = double.Parse(Console.ReadLine());
        Console.Write("Digite seu segundo número: ");
        b = double.Parse(Console.ReadLine());
        Console.Write("Digite seu terceiro número: ");
        c = double.Parse(Console.ReadLine());
        x = a+b-c;
        Console.WriteLine("O valor de X é: " + x);

    }
}