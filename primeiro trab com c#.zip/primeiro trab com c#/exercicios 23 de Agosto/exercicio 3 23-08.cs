using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Soma de A e B");
        int a, b, c, d, x;
        Console.Write("Digite o valor de A: ");
        a = int.Parse(Console.ReadLine());
        Console.Write("Digite o valor de B: ");
        b = int.Parse(Console.ReadLine());
        Console.Write("Digite o valor de C: ");
        c = int.Parse(Console.ReadLine());
        Console.Write("Digite o valor de D: ");
        d = int.Parse(Console.ReadLine());
        x = (a + b)/c-d;
        Console.WriteLine("A soma é: " + x);
    }
}