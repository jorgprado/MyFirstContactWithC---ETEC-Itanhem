﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Calcule a área do retângulo ");
        int area, bs, altura;
        Console.Write("Digite o valor da base: ");
        bs = int.Parse(Console.ReadLine());
        Console.Write("Digite a altura: ");
        altura = int.Parse(Console.ReadLine());
        area = bs * altura;
        Console.WriteLine("A area do retângulo é:" + area);
    }
}
