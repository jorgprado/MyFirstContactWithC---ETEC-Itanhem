﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Calcule aqui o resto da Divisão: ");
        double x, a, b;
        Console.Write("Digite um número: ");
        a = double.Parse(Console.ReadLine());
        Console.Write("Digite um segundo número: ");
        b = double.Parse(Console.ReadLine());
        x = a % b;
        Console.WriteLine("O resto da divisão é: " + x);
    }
}