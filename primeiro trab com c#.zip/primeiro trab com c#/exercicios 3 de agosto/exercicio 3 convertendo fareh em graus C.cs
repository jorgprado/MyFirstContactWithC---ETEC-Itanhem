﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Converta fahrenheit em Celsiu: ");
        double c, f;
        Console.Write("Digite a temperatura em fahrenheit: ");
        f = double.Parse(Console.ReadLine());
        c = (f - 32) / 1.8;
        Console.WriteLine("A temperatura em Graus Celsius é: " + c);
    }
}