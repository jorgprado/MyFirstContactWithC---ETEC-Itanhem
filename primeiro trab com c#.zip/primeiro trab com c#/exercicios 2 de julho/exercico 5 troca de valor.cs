﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Troca de Valores");
        double A, B, C;
        Console.Write("Digite um valor para A: ");
        A = double.Parse(Console.ReadLine());
        Console.Write("Digite um valor para B: ");
        B = double.Parse(Console.ReadLine());
        C = A;
        A = B;
        B = C;
        Console.WriteLine(" A= " + A + " B= " + B);
    }
}