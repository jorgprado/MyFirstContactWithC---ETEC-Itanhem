﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Calcule quanto um professor ganhar");
        double salario, qt, vh, inss;
        Console.Write("Digite a quantidades de aulas dadas: ");
        qt = double.Parse(Console.ReadLine());
        Console.Write("Digite o valor da da hora aula: ");
        vh = double.Parse(Console.ReadLine());
        Console.Write("Digite o percentual de INSS: ");
        inss = double.Parse(Console.ReadLine());
        salario = qt * vh * (1 - inss / 100);
        Console.WriteLine("O salário líquido do professo é " + salario);            
    }
}
