﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Área da circunferência ");
        double area, raio;
        Console.Write("Digite o valor de Raio: ");
        raio = double.Parse(Console.ReadLine());
        area = 3.14*(raio*raio);
        Console.WriteLine("A area da Circunferência é:" + area);
    }
}