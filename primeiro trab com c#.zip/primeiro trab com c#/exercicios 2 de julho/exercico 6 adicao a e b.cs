﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Soma de A e B");
        int a, b, soma;
        Console.Write("Digite o valor de A: ");
        a = int.Parse(Console.ReadLine());
        Console.Write("Digite o valor de B: ");
        b = int.Parse(Console.ReadLine());
        soma = a + b;
        Console.WriteLine("A soma de: " + a + " + " + b + " é igual a: " + soma);
    }
}